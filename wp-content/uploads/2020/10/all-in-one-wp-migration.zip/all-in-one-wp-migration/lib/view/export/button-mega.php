<a href="https://servmask.com/products/mega-extension" target="_blank"><?php _e( 'Mega', AI1WM_PLUGIN_NAME ); ?></a>
